<?php
  sleep(10);
?>
