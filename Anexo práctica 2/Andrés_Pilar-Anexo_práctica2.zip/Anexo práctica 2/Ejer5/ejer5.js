/*5º) Utilizando el método $.get traer un fichero de texto.
Si el fichero de texto se puede traer correctamente que lo muestre,
en caso contrario que lo indique con  un mensaje de error.
(ver los capítulos 53-54 de la página de desarrolloweb para realizar este ejercicio).*/
