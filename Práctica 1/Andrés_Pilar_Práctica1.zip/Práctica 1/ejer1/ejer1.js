$(document).ready(function()
{
  var n=$("div");

  alert("Hay " + n.length + " divs");
  $("div").css("color","green");
});
